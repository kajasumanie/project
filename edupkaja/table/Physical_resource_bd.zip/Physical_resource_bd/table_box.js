$(document).ready(function() {
				$('#fixTable').tableHeadFixer({"head" : false, "right" : 1});
				$("#fixTable").tableHeadFixer({"head" : false, "left" : 2});
				$("#fixTable").tableHeadFixer({"left" : 2, "right" : 2});
			});


    //<![CDATA[
      $(document).ready(function() {
        $("#filter").multifilter()
      })
    //]]>
